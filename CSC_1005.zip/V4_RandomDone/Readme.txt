### 測試用帳號：test1 、密碼：12345

##### new_index.php 有套用模板的首頁介面(首頁從此進入)

##### 2_viewBoard.php 評論服飾的頁面(Write Review)
    
    共8樣｜　網址分別是2_viewBoard.php?id=(1-8)

##### 3_viewRevise.php "修改"評論服飾的頁面(Revise the previous Review)
    
         ｜　網址分別是3_viewRevise.php?id=(1-8)

##### 4_question.php 填答真實度問題的頁面


-----------------------------------

##### main.htm　主介面（new_index.php）的模板

	.1 single.php 單一留言的模板
	.2 keyword.htm 服裝類別（直行呈現）的模板


### rating_page.htm 跟撰寫評論相關的前端



##### uploads 服飾圖片放這邊
    * 格式=> product_服飾編號

##### pdo.php 連接資料庫用的


##### CSC_1004.sql 資料庫sql檔案

##### template_class.php